package com.hershyuzhe.gpstrackermobile;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.Priority;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.tasks.Task;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    // Location update intervals (in seconds)
    public static final int DEFAULT_UPDATE_INTERVAL = 30; // normal interval
    public static final int FAST_UPDATE_INTERVAL = 5;     // faster interval when available

    // Request codes
    private static final int LOCATION_PERMISSION_REQUEST = 1001;
    private static final int REQUEST_CHECK_SETTINGS = 1002;

    // UI elements
    private TextView tv_lat, tv_lon, tv_altitude, tv_accuracy, tv_speed, tv_sensor, tv_updates, tv_address;
    private Switch sw_locationupdates, sw_gps, sw_units;
    private Chronometer chronometer;

    // Buttons
    private Button btnHelp, btnReset, btnIncreaseFont, btnDecreaseFont;

    // Current font size in SP; used by Increase/Decrease Font
    private float currentFontSizeSp = 14f;

    // Toggle whether speed is shown in Km/Hr or Miles/Hr
    private boolean showKmH = false; // false => Miles/Hr, true => Km/Hr

    // Location services
    private FusedLocationProviderClient fusedLocationProviderClient;
    private LocationRequest locationRequest;
    private LocationCallback locationCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);  // Ensure your layout matches these IDs

        // 1) Initialize UI references
        tv_lat = findViewById(R.id.tv_lat);
        tv_lon = findViewById(R.id.tv_lon);
        tv_altitude = findViewById(R.id.tv_altitude);
        tv_accuracy = findViewById(R.id.tv_accuracy);
        tv_speed = findViewById(R.id.tv_speed);
        tv_sensor = findViewById(R.id.tv_sensor);
        tv_updates = findViewById(R.id.tv_updates);
        tv_address = findViewById(R.id.tv_address);
        sw_locationupdates = findViewById(R.id.sw_locationsupdates);
        sw_gps = findViewById(R.id.sw_gps);
        sw_units = findViewById(R.id.sw_units);
        chronometer = findViewById(R.id.chronometer);

        // 2) Initialize buttons
        btnHelp = findViewById(R.id.btn_help);
        btnReset = findViewById(R.id.reset);
        btnIncreaseFont = findViewById(R.id.btn_increase);
        btnDecreaseFont = findViewById(R.id.btn_decrease);

        // 3) FusedLocationProviderClient
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        // 4) Create a default LocationRequest (High Accuracy)
        createLocationRequest();

        // 5) Check location settings (prompts user if GPS is off)
        checkLocationSettings();

        // 6) LocationCallback for receiving location updates
        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(@NonNull LocationResult locationResult) {
                super.onLocationResult(locationResult);
                for (Location location : locationResult.getLocations()) {
                    updateUI(location);
                }
            }
        };

        // 7) Switch: Use GPS sensor vs. Balanced Power
        sw_gps.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                // High accuracy: GPS
                locationRequest = new LocationRequest.Builder(
                        Priority.PRIORITY_HIGH_ACCURACY,
                        1000L * DEFAULT_UPDATE_INTERVAL
                ).setMinUpdateIntervalMillis(1000L * FAST_UPDATE_INTERVAL)
                        .build();
                tv_sensor.setText("Using GPS Sensor");
            } else {
                // Balanced Power Accuracy: Cell towers + WiFi
                locationRequest = new LocationRequest.Builder(
                        Priority.PRIORITY_BALANCED_POWER_ACCURACY,
                        1000L * DEFAULT_UPDATE_INTERVAL
                ).setMinUpdateIntervalMillis(1000L * FAST_UPDATE_INTERVAL)
                        .build();
                tv_sensor.setText("Using Cellular + WIFI");
            }

            // If location updates are on, re-request them with the new settings
            if (sw_locationupdates.isChecked()) {
                requestLocationUpdates();
            }
        });

        // 8) Switch: Toggle location updates on/off
        sw_locationupdates.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                requestLocationUpdates();
                tv_updates.setText("On");

                // Reset & start chronometer
                chronometer.setBase(SystemClock.elapsedRealtime());
                chronometer.start();
            } else {
                stopLocationUpdates();
                tv_updates.setText("Off");

                // Reset chronometer
                chronometer.stop();
                chronometer.setBase(SystemClock.elapsedRealtime());

                // Clear displayed values
                resetAllValuesToZero();
            }
        });

        // 9) Switch: Show speed in Km/Hr vs. Miles/Hr
        sw_units.setOnCheckedChangeListener((buttonView, isChecked) -> {
            showKmH = isChecked;
            // If location updates are on, refresh with last known location
            if (sw_locationupdates.isChecked()) {
                getLastKnownLocation();
            }
        });

        // 10) Button: Help (AlertDialog)
        btnHelp.setOnClickListener(v -> showHelpDialog());

        // 11) Button: Reset
        btnReset.setOnClickListener(v -> {
            // Turn off location updates if they are on
            if (sw_locationupdates.isChecked()) {
                sw_locationupdates.setChecked(false);
            }
            resetAllValuesToZero();
            Toast.makeText(this, "Values reset.", Toast.LENGTH_SHORT).show();
        });

        // 12) Button: Increase Font
        btnIncreaseFont.setOnClickListener(v -> {
            currentFontSizeSp += 2f; // Increase by 2 SP
            setAllTextViewsFontSize(currentFontSizeSp);
        });

        // 13) Button: Decrease Font
        btnDecreaseFont.setOnClickListener(v -> {
            // Decrease, but keep at least 10 SP
            currentFontSizeSp = Math.max(10f, currentFontSizeSp - 2f);
            setAllTextViewsFontSize(currentFontSizeSp);
        });

        // 14) Initialize fields to default (0.0, etc.)
        resetAllValuesToZero();
    }

    /**
     * Create the initial LocationRequest with default intervals (High Accuracy).
     */
    private void createLocationRequest() {
        locationRequest = new LocationRequest.Builder(
                Priority.PRIORITY_HIGH_ACCURACY,
                1000L * DEFAULT_UPDATE_INTERVAL
        ).setMinUpdateIntervalMillis(1000L * FAST_UPDATE_INTERVAL)
                .build();
    }

    /**
     * Check if device's location settings (GPS, etc.) are on; prompt user if off.
     */
    private void checkLocationSettings() {
        LocationSettingsRequest.Builder builder =
                new LocationSettingsRequest.Builder().addLocationRequest(locationRequest);

        SettingsClient settingsClient = LocationServices.getSettingsClient(this);
        Task<Void> task = settingsClient
                .checkLocationSettings(builder.build())
                .continueWithTask(t -> null);

        task.addOnFailureListener(e -> {
            if (e instanceof ResolvableApiException) {
                try {
                    ((ResolvableApiException) e).startResolutionForResult(
                            this, REQUEST_CHECK_SETTINGS
                    );
                } catch (IntentSender.SendIntentException sendEx) {
                    sendEx.printStackTrace();
                }
            }
        });
    }

    /**
     * Show a help dialog that explains usage instructions.
     */
    private void showHelpDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("How to Use GPS Tracker")
                .setMessage("1. Allow the app to access your location.\n" +
                        "2. Use 'Location Updates' switch to start/stop.\n" +
                        "3. Use 'GPS/SavePower' switch to switch accuracy.\n" +
                        "4. Use 'Use Km/Hr?' switch to toggle speed units.\n" +
                        "5. Use 'Increase/Decrease Font Size' to adjust text.\n" +
                        "6. Press 'Help' any time for guidance!")
                .setPositiveButton("OK", (dialog, which) -> dialog.dismiss());

        AlertDialog dialog = builder.create();
        dialog.show();

        // Optionally resize the dialog for readability
        if (dialog.getWindow() != null) {
            dialog.getWindow().setLayout(1100, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }

    /**
     * Request location updates if permission is granted; otherwise request permission.
     */
    @SuppressLint("MissingPermission")
    private void requestLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                    LOCATION_PERMISSION_REQUEST
            );
            return;
        }
        fusedLocationProviderClient.requestLocationUpdates(locationRequest, locationCallback, null);
        getLastKnownLocation(); // also fetch last known location
    }

    /**
     * Stop location updates.
     */
    private void stopLocationUpdates() {
        fusedLocationProviderClient.removeLocationUpdates(locationCallback);
    }

    /**
     * Reset UI text to default placeholders.
     */
    private void resetAllValuesToZero() {
        tv_lat.setText("0.0");
        tv_lon.setText("0.0");
        tv_altitude.setText("0.0");
        tv_accuracy.setText("0.0");
        tv_speed.setText("0.0");
        tv_address.setText("Turn on Update Location");
        // If you wish to reset color, do so here. e.g.:
        tv_speed.setTextColor(getResources().getColor(android.R.color.black));
    }

    /**
     * Fetch the last known location once (if permission granted).
     */
    @SuppressLint("MissingPermission")
    private void getLastKnownLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            fusedLocationProviderClient.getLastLocation()
                    .addOnSuccessListener(location -> {
                        if (location != null && sw_locationupdates.isChecked()) {
                            updateUI(location);
                        }
                    });
        } else {
            // Request permission again
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                    LOCATION_PERMISSION_REQUEST
            );
        }
    }

    /**
     * Update UI with the provided location. Includes speed (color-coded) & address lookup.
     */
    private void updateUI(Location location) {
        if (location == null) return;

        // speed in m/s
        float speedMs = location.getSpeed();

        float displayedSpeed;
        String unitLabel;
        if (showKmH) {
            displayedSpeed = speedMs * 3.6f;  // convert m/s to km/h
            unitLabel = "Km/Hr";
        } else {
            displayedSpeed = speedMs * 2.23694f; // convert m/s to mph
            unitLabel = "Miles/Hr";
        }

        tv_lat.setText(String.format(Locale.getDefault(), "%.6f", location.getLatitude()));
        tv_lon.setText(String.format(Locale.getDefault(), "%.6f", location.getLongitude()));
        tv_altitude.setText(String.format(Locale.getDefault(), "%.2f", location.getAltitude()));
        tv_accuracy.setText(String.format(Locale.getDefault(), "%.2f", location.getAccuracy()));

        // Show speed with proper units
        tv_speed.setText(String.format(Locale.getDefault(), "%.2f %s", displayedSpeed, unitLabel));

        // Color-code speed
        if (displayedSpeed <= 30) {
            tv_speed.setTextColor(getResources().getColor(android.R.color.holo_green_light));
        } else if (displayedSpeed <= 60) {
            tv_speed.setTextColor(getResources().getColor(android.R.color.holo_orange_light));
        } else {
            tv_speed.setTextColor(getResources().getColor(android.R.color.holo_red_light));
        }

        // Reverse geocoding to get address
        getAddressFromLocation(location.getLatitude(), location.getLongitude());
    }

    /**
     * Convert latitude/longitude to a street address (reverse geocoding).
     */
    private void getAddressFromLocation(double latitude, double longitude) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
            if (addresses != null && !addresses.isEmpty()) {
                Address address = addresses.get(0);
                tv_address.setText(address.getAddressLine(0));
            } else {
                tv_address.setText("No address found");
            }
        } catch (IOException e) {
            e.printStackTrace();
            tv_address.setText("Unable to get address");
        }
    }

    /**
     * Adjust font size of all relevant TextViews.
     */
    private void setAllTextViewsFontSize(float sizeSp) {
        tv_lat.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp);
        tv_lon.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp);
        tv_altitude.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp);
        tv_accuracy.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp);
        tv_speed.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp);
        tv_sensor.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp);
        tv_updates.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp);
        tv_address.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp);
    }

    /**
     * Stop updates and chronometer when Activity is destroyed.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopLocationUpdates();
        chronometer.stop();
    }

    /**
     * Handle permission request results (location).
     */
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == LOCATION_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // If user granted permission, request location updates if switch is ON
                if (sw_locationupdates.isChecked()) {
                    requestLocationUpdates();
                }
            } else {
                // Permission denied
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
